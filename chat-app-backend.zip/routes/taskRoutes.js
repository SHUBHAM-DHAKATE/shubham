const express = require("express");
const router = express.Router();
const Task = require("../models/Task");

router.post("/", async (req, res) => {
  const task = new Task(req.body);
  await task.save();
  res.json(task);
});

router.get("/", async (req, res) => {
  const tasks = await Task.find().populate("assigned_to created_by");
  res.json(tasks);
});

module.exports = router;