const express = require("express");
const router = express.Router();
const Message = require("../models/Message");

router.post("/", async (req, res) => {
  const msg = new Message(req.body);
  await msg.save();
  res.json(msg);
});

router.get("/", async (req, res) => {
  const msgs = await Message.find().populate("sender_id chat_id");
  res.json(msgs);
});

module.exports = router;