const express = require("express");
const router = express.Router();
const Meeting = require("../models/Meeting");

router.post("/", async (req, res) => {
  const meeting = new Meeting(req.body);
  await meeting.save();
  res.json(meeting);
});

router.get("/", async (req, res) => {
  const meetings = await Meeting.find().populate("chat_id hosted_by");
  res.json(meetings);
});

module.exports = router;