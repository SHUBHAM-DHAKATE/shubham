const express = require("express");
const router = express.Router();
const Chat = require("../models/Chat");

router.post("/", async (req, res) => {
  const chat = new Chat(req.body);
  await chat.save();
  res.json(chat);
});

router.get("/", async (req, res) => {
  const chats = await Chat.find().populate("participants admin");
  res.json(chats);
});

module.exports = router;