const mongoose = require("mongoose");

const fileSchema = new mongoose.Schema({
  type: String,
  chat_id: { type: mongoose.Schema.Types.ObjectId, ref: "Chat" },
  meeting_id: { type: mongoose.Schema.Types.ObjectId, ref: "Meeting" },
  filename: String,
  file_url: String,
  uploaded_by: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model("File", fileSchema);