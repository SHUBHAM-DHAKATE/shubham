const mongoose = require("mongoose");

const taskSchema = new mongoose.Schema({
  title: String,
  description: String,
  assigned_to: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  created_by: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  deadline: Date,
  status: { type: String, enum: ["open", "in-progress", "done"], default: "open" },
  source_message_id: { type: mongoose.Schema.Types.ObjectId, ref: "Message" }
});

module.exports = mongoose.model("Task", taskSchema);