const mongoose = require("mongoose");

const meetingNotesSchema = new mongoose.Schema({
  meeting_id: { type: mongoose.Schema.Types.ObjectId, ref: "Meeting" },
  summary: String,
  key_words: [String]
});

module.exports = mongoose.model("MeetingNotes", meetingNotesSchema);