const mongoose = require("mongoose");

const chatSchema = new mongoose.Schema({
  chat_type: { type: String, enum: ["1:1", "group"] },
  created_at: { type: Date, default: Date.now },
  participants: [{ type: mongoose.Schema.Types.ObjectId, ref: "User" }],
  admin: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
});

module.exports = mongoose.model("Chat", chatSchema);