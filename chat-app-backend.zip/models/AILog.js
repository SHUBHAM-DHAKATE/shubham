const mongoose = require("mongoose");

const aiLogSchema = new mongoose.Schema({
  feature: String,
  input_ref: String,
  output_data: String,
  created_at: { type: Date, default: Date.now }
});

module.exports = mongoose.model("AILog", aiLogSchema);