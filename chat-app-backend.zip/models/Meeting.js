const mongoose = require("mongoose");

const meetingSchema = new mongoose.Schema({
  title: String,
  chat_id: { type: mongoose.Schema.Types.ObjectId, ref: "Chat" },
  created_at: { type: Date, default: Date.now },
  start_time: Date,
  end_time: Date,
  hosted_by: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  meeting_link: String,
  recording_url: String,
  notes_id: { type: mongoose.Schema.Types.ObjectId, ref: "MeetingNotes" }
});

module.exports = mongoose.model("Meeting", meetingSchema);