const mongoose = require("mongoose");

const attendanceSchema = new mongoose.Schema({
  meeting_id: { type: mongoose.Schema.Types.ObjectId, ref: "Meeting" },
  user_id: { type: mongoose.Schema.Types.ObjectId, ref: "User" },
  join_time: Date,
  leave_time: Date
});

module.exports = mongoose.model("Attendance", attendanceSchema);